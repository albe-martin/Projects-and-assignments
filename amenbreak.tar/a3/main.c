// 13-blink - main.c for gpio hello world

#include "uart.h"
#include "amen.h"

#define GPIO_BASE 0xfe200000

#define RED 5
#define GRN 6
#define SW1 3
#define SW2 2
#define AUDIO1 40
#define AUDIO2 41

#define TIMER_BASE 0xFE003000

#define CS      0
#define CLO     1
#define CHI     2

unsigned long getSystemTimerCounter() {
    // from  https://embedded-xinu.readthedocs.io/en/latest/arm/rpi/BCM2835-System-Timer.html
    volatile unsigned int *timer = (unsigned int *)TIMER_BASE;
    unsigned int h=-1, l;
    
    // we must read MMIO area as two separate 32 bit reads
    h = timer[CHI];
    l = timer[CLO];

    // we have to repeat it if high word changed during read
    //   - low low counter rolled over
    if ( h != timer[CHI] ) {
        h = timer[CHI];
        l = timer[CLO];
     }
    // compose long int value
    return ((unsigned long) h << 32) | (unsigned long)l;
}



void initGPIO() {
    volatile unsigned int *gpio = (unsigned int *)GPIO_BASE;
    
    // set up for output
    gpio[ RED / 10 ] &= ~ (0b111 << ((RED % 10) * 3) );    // clear bits for gpio pin 5
    gpio[ RED / 10] |= 0b001 << ((RED % 10) * 3);         // init gpio pin 5 for output = 0b001

    gpio[ GRN / 10 ] &= ~ (0b111 << ((GRN % 10) * 3) );    // clear bits for gpio pin 6
    gpio[ GRN / 10] |= 0b001 << ((GRN % 10) * 3);         // init gpio pin 6 for output = 0b001

    gpio[ AUDIO1 / 10 ] &= ~ (0b111 << ((AUDIO1 % 10) * 3) );    // clear bits for gpio pin 6
    gpio[ AUDIO1 / 10] |= 0b001 << ((AUDIO1 % 10) * 3);         // init gpio pin 6 for output = 0b001

    gpio[ AUDIO2 / 10 ] &= ~ (0b111 << ((AUDIO2 % 10) * 3) );    // clear bits for gpio pin 6
    gpio[ AUDIO2 / 10] |= 0b001 << ((AUDIO2 % 10) * 3);         // init gpio pin 6 for output = 0b001

    gpio[SW1 / 10] &= ~(0b111 << ((SW1 % 10) * 3));
    gpio[SW2 / 10] &= ~(0b111 << ((SW2 % 10) * 3));

    gpio[57 + SW1 / 16] &= ~(0b11 << (2 * (SW1 % 16)));
    gpio[57 + SW1 / 16] |= 0b01 << (2 * (SW1 % 16));

    gpio[57 + SW2 / 16] &= ~(0b11 << (2 * (SW2 % 16)));
    gpio[57 + SW2 / 16] |= 0b01 << (2 * (SW2 % 16));

    gpio[57 + AUDIO1 / 16] &= ~(0b11 << (2 * (AUDIO1 % 16)));
    gpio[57 + AUDIO1 / 16] |= 0b01 << (2 * (AUDIO1 % 16));

    gpio[57 + AUDIO2 / 16] &= ~(0b11 << (2 * (AUDIO2 % 16)));
    gpio[57 + AUDIO2 / 16] |= 0b01 << (2 * (AUDIO2 % 16));
}

void pinOn( int pin ) {
    volatile unsigned int *gpio = (unsigned int *) GPIO_BASE;

    gpio[7 + pin/32] = 1 << pin%32;
}


void pinOff( int pin ) {
    volatile unsigned int *gpio = (unsigned int *) GPIO_BASE;

    gpio[10 + pin/32] = 1 << pin%32;
}

int readPin( int pin ) {
    volatile unsigned int *gpio = (unsigned int *) GPIO_BASE;

    return (gpio[13 + pin/32] >> pin%32) & 0b1;     // get corresponding bit from GPLEV0
}

void delay( unsigned int t ) {
    long tEnd = t + getSystemTimerCounter();
    
    while( getSystemTimerCounter() < tEnd );
    
}

void playAudioForward(){
    volatile unsigned int *gpio = (unsigned int *) GPIO_BASE;
    
    for(int i=0; i < AMEN_LENGTH; i++){
        unsigned int time = ((int)amen[i] * 104)/63;
        pinOn(AUDIO1);
        pinOn(AUDIO2);
        delay(time);
        pinOff(AUDIO1);
        pinOff(AUDIO2);
        delay(104 - time);    
    }    
}

void playAudioBackward(){
    volatile unsigned int *gpio = (unsigned int *) GPIO_BASE;
    
    for(int i=AMEN_LENGTH-1; i>=0; i--){
        unsigned int time = ((int)amen[i] * 104)/63;
        pinOn(AUDIO1);
        pinOn(AUDIO2);
        delay(time);
        pinOff(AUDIO1);
        pinOff(AUDIO2);
        delay(104 - time);
    }
}

int main() {
    initGPIO();
    pinOn(GRN);
    pinOn(RED);
    while(1) {
        if (readPin(SW1) == 0) {
            pinOff(RED);
            playAudioBackward();
            pinOn(GRN);
        } else if (readPin(SW2) == 0) {
            pinOff(GRN);
            playAudioForward();
            pinOn(RED);
        } else {
            pinOn(RED);
            pinOn(GRN);
        }
    }
    return 0;
}






















/*
#include "uart.h"

#define GPIO_BASE 0xFE200000



#define TIMER_BASE 0xFE003000

#define CS      0
#define CLO     1
#define CHI     2
#define C0      3
#define C1      4
#define C2      5
#define C3      6


void utocx( unsigned int n, char *s, int size ) {
    int i;

    // start with null termination - we are interting things backwards
    s[0] = 0;

    // insert the digits starting with least significant
    i = 1;      // start after the null termination
    do {
        int lsdigit = n % 16;
        if ( lsdigit < 10 )
            s[i++] = lsdigit % 10 + '0';
        else
            s[i++] = lsdigit-10 + 'a';
        n /= 16;
    } while( n != 0  && i < size );

    // reverse string
    char temp;
    i--;
    for( int j = 0; j < i; j++ ) {
        temp = s[j];
        s[j] = s[i];
        s[i--] = temp;
    }
}



unsigned long getSystemTimerCounter() {
    // from  https://embedded-xinu.readthedocs.io/en/latest/arm/rpi/BCM2835-System-Timer.html
    volatile unsigned int *timer = (unsigned int *)TIMER_BASE;
    unsigned int h=-1, l;
    
    // we must read MMIO area as two separate 32 bit reads
    h = timer[CHI];
    l = timer[CLO];

    // we have to repeat it if high word changed during read
    //   - low low counter rolled over
    if ( h != timer[CHI] ) {
        h = timer[CHI];
        l = timer[CLO];
     }
    // compose long int value
    return ((unsigned long) h << 32) | (unsigned long)l;
}

// Traffic Light pins
#define RED_LIGHT_PIN  5
#define GREEN_LIGHT_PIN  6
#define YELLOW_LIGHT_PIN  13
#define SW1_PIN  3
#define SW2_PIN  2




void initTrafficLightPins() {
    volatile unsigned int *gpio = (unsigned int *) GPIO_BASE;
    
    // init led pins for outuput
    gpio[RED_LIGHT_PIN/10] &= ~(0b111 << (3*(RED_LIGHT_PIN % 10)));         // clear function select bits (input)
    gpio[RED_LIGHT_PIN/10] |=   0b001 << (3*(RED_LIGHT_PIN % 10)) ;         // function select bits to output
    
    gpio[GREEN_LIGHT_PIN/10] &= ~(0b111 << (3*(GREEN_LIGHT_PIN % 10)));     // clear function select bits (input)
    gpio[GREEN_LIGHT_PIN/10] |=   0b001 << (3*(GREEN_LIGHT_PIN % 10)) ;     // function select bits to output
    
    gpio[YELLOW_LIGHT_PIN/10] &= ~(0b111 << (3*(YELLOW_LIGHT_PIN % 10)));   // clear function select bits (input)
    gpio[YELLOW_LIGHT_PIN/10] |=   0b001 << (3*(YELLOW_LIGHT_PIN % 10)) ;   // function select bits to output
    
    // init switch pins for input
    gpio[SW1_PIN/10] &= ~(0b111 << (3*(SW1_PIN % 10)));     // clear function select bits (input)
    gpio[SW2_PIN/10] &= ~(0b111 << (3*(SW2_PIN % 10)));     // clear function select bits (input)
    
    // activate pull-ups for switches
    gpio[57 + SW1_PIN/16] &= ~(0b11 << (2*(SW1_PIN % 16)));     // clear pull-up-down (no resistor)
    gpio[57 + SW1_PIN/16] |=   0b01 << (2*(SW1_PIN % 16)) ;     // insert bit pattern for pull-up
    
    gpio[57 + SW2_PIN/16] &= ~(0b11 << (2*(SW2_PIN % 16)));     // clear pull-up-down (no resistor)
    gpio[57 + SW2_PIN/16] |=   0b01 << (2*(SW2_PIN % 16)) ;     // insert bit pattern for pull-up
}


void pinOn( int pin ) {
    volatile unsigned int *gpio = (unsigned int *) GPIO_BASE;

    gpio[7] = 1 << pin;
}


void pinOff( int pin ) {
    volatile unsigned int *gpio = (unsigned int *) GPIO_BASE;

    gpio[10] = 1 << pin;
}

int readPin( int pin ) {
    volatile unsigned int *gpio = (unsigned int *) GPIO_BASE;

    return (gpio[13] >> pin) & 0b1;     // get corresponding bit from GPLEV0
}



int main() {
    unsigned long int tSwitch;

    uart_init();
    initTrafficLightPins();
    
    while(1) {
        pinOn( RED_LIGHT_PIN );
        pinOn( GREEN_LIGHT_PIN );
        pinOn( YELLOW_LIGHT_PIN );
        
        uart_puts( "SW1:  " );
        if ( readPin( SW1_PIN ) ) uart_puts( "on\n" );
        else uart_puts( "off\n" );
        uart_puts( "SW2:  " );
        if ( readPin( SW2_PIN ) ) uart_puts( "on\n" );
        else uart_puts( "off\n" );
        
        tSwitch = getSystemTimerCounter() + 500000;
        while( getSystemTimerCounter() < tSwitch );
        pinOff( RED_LIGHT_PIN );
        pinOff( GREEN_LIGHT_PIN );
        pinOff( YELLOW_LIGHT_PIN );
        tSwitch = getSystemTimerCounter() + 500000;
        while( getSystemTimerCounter() < tSwitch );
    }

    return 0;
}

*/




