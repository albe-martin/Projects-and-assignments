// timer.h - Pi 4 sytem timer functions

unsigned long long getSystemTimerCounter();
void delayus( unsigned int delay );
void delay( unsigned int ms );

